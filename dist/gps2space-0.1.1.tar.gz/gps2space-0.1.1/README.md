# GPS2space
A Python library for building spatial data and calculating buffer- and Convex hull-based activity space from raw GPS data.